package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.UpdateProfile;
import com.example.demo.services.UpdateProfileService;


@RestController
@RequestMapping("api")
public class UpdateProfileController {
	
	
	@Autowired
	private UpdateProfileService updateProfileService;
	
	@PostMapping("/updateProfile/{id}")
	public ResponseEntity<UpdateProfile> updateProfile(@PathVariable("id") long id,
			@RequestBody UpdateProfile updateProfile) {
		return new ResponseEntity<UpdateProfile>(updateProfileService.updateProfile(updateProfile, id), HttpStatus.OK);
	

	}
	
}

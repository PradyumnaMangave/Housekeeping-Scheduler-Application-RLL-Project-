package com.example.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entities.Housekeeper;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repositories.HousekeeperRepository;

@Service
public class HousekeeperServiceImpl implements HousekeeperService{
	
    @Autowired
	private HousekeeperRepository housekeeperRepository;

	public HousekeeperServiceImpl(HousekeeperRepository housekeeperRepository) {
		super();
		this.housekeeperRepository = housekeeperRepository;
	}

	@Override
	public Housekeeper saveEmployee(Housekeeper employee) {
		return housekeeperRepository.save(employee);
	}

	@Override
	public List<Housekeeper> getAllEmployees() {
		return housekeeperRepository.findAll();
	}

	@Override
	public Housekeeper getEmployeeById(long id) {
		return housekeeperRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Housekeeper", "Id", id));

	}

	@Override
	public Housekeeper updateEmployee(Housekeeper employee, long id) {

		Housekeeper employeeDetails = housekeeperRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee", "Id", id));

		employeeDetails.setName(employee.getName());
		employeeDetails.setHostelName(employee.getHostelName());
		employeeDetails.setFloor(employee.getFloor());
		employeeDetails.setComplaints(employee.getComplaints());
		

		housekeeperRepository.save(employeeDetails);
		return employeeDetails;
	}

	@Override
	public void deleteEmployee(long id) {

		housekeeperRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Housekeeper", "Id", id));
		housekeeperRepository.deleteById(id);
	}


}

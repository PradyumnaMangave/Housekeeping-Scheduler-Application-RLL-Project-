package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.AdminRegistration;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repositories.AdminRegRepo;


@Service
public class AdminRegImpl implements AdminRegistrationService{
	
	
	@Autowired
	private AdminRegRepo adminRegRepo;

	public AdminRegImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public AdminRegistration saveAdminRegistration(AdminRegistration employeeRegistration) {
		return adminRegRepo.save(employeeRegistration);
	}

	@Override
	public List<AdminRegistration> getAllAdmin() {
		return adminRegRepo.findAll();
	}

	@Override
	public AdminRegistration getAdminRegistrationById(long id) {
		return adminRegRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee", "Id", id));

	}

}

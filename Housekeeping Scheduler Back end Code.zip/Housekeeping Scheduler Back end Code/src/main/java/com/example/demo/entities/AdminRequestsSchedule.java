 package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employeeWork_schedule")
public class AdminRequestsSchedule {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private long id;

	@Column(name = "emp_name")
	private String emp_name;
	
	@Column(name = "hostel")
	private int hostel;

	@Column(name = "floor")
	private int floor;

	@Column(name = "rooms_cleaned")
	private String rooms_cleaned;
	
	@Column(name="complains")
	private int complains;

	public AdminRequestsSchedule() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminRequestsSchedule(long id, String emp_name, int hostel, int floor, String rooms_cleaned, int complains) {
		super();
		this.id = id;
		this.emp_name = emp_name;
		this.hostel = hostel;
		this.floor = floor;
		this.rooms_cleaned = rooms_cleaned;
		this.complains = complains;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public int getHostel() {
		return hostel;
	}

	public void setHostel(int hostel) {
		this.hostel = hostel;
	}

	public int getFloor() {
		return floor;
	}

	public void setFloor(int floor) {
		this.floor = floor;
	}

	public String getRooms_cleaned() {
		return rooms_cleaned;
	}

	public void setRooms_cleaned(String rooms_cleaned) {
		this.rooms_cleaned = rooms_cleaned;
	}

	public int getComplains() {
		return complains;
	}

	public void setComplains(int complains) {
		this.complains = complains;
	}

	@Override
	public String toString() {
		return "AdminWorkSchedule [id=" + id + ", emp_name=" + emp_name + ", hostel=" + hostel + ", floor=" + floor
				+ ", rooms_cleaned=" + rooms_cleaned + ", complains=" + complains + "]";
	}

	
}
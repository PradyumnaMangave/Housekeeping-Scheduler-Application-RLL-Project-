package com.example.demo.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.AdminMaintenance;
import com.example.demo.services.AdminMaintenanceService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api")
public class AdminMaintenanceController {
	
	@Autowired
	private AdminMaintenanceService adminMaintenanceService;

	public AdminMaintenanceController() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@PostMapping("/schedules")
	public ResponseEntity<AdminMaintenance> saveHousekeeper(@RequestBody AdminMaintenance adminWorkSchedule) {
		return new ResponseEntity<AdminMaintenance>(adminMaintenanceService.saveAdminWorkSchedule(adminWorkSchedule),
				HttpStatus.CREATED);
	}

	@GetMapping("/schedules")
	public List<AdminMaintenance> getAllHousekeepers() {
		return adminMaintenanceService.getAllWork();
	}

	@GetMapping("/schedules/{id}")
	public ResponseEntity<AdminMaintenance> getHousekeeperById(@PathVariable("id") long id) {
		return new ResponseEntity<AdminMaintenance>(adminMaintenanceService.getWorkById(id), HttpStatus.OK);
	}

	@CrossOrigin(origins="http://localhost:4200")
	@PutMapping(value="/schedules/{id}",produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AdminMaintenance> updateHousekeeper(@PathVariable("id") long id,
			@RequestBody AdminMaintenance adminWorkSchedule) {
		return new ResponseEntity<AdminMaintenance>(
				adminMaintenanceService.updateWorkSchedule(adminWorkSchedule, id), HttpStatus.OK);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/schedules/{id}")
	public ResponseEntity<String> deleteHousekeeper(@PathVariable("id") long id) {
 
		adminMaintenanceService.deleteWork(id);

		return new ResponseEntity<String>("Work Schedule deleted successfully!.", HttpStatus.OK);
	}

}

package com.example.demo.services;

import java.util.List;



import com.example.demo.entities.AdminMaintenance;


public interface AdminMaintenanceService {
	
	AdminMaintenance saveAdminWorkSchedule(AdminMaintenance adminWorkSchedule);

	List<AdminMaintenance> getAllWork();

	AdminMaintenance getWorkById(long empid);

	AdminMaintenance updateWorkSchedule(AdminMaintenance adminWorkSchedule, long empid);

	void deleteWork(long empid);

}

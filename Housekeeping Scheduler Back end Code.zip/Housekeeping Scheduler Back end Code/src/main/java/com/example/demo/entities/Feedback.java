package com.example.demo.entities;

import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GenerationType;

@Entity
@Table(name="Feedback")
public class Feedback {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "feedback_id")
	private int feedback_id;
	@Column(name = "rollnumber")
	private int rollnumber;
	@Column(name = "request_id")
	private int request_id;
	@Column(name = "rating")
	private int rating;
	@Column(name = "timeIn")
	private Time timeIn;
	@Column(name = "timeOut")
	private Time timeOut;
	
	
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Feedback(int feedback_id, int rollnumber, int request_id, int rating, Time timeIn, Time timeOut) {
		super();
		this.feedback_id = feedback_id;
		this.rollnumber = rollnumber;
		this.request_id = request_id;
		this.rating = rating;
		this.timeIn = timeIn;
		this.timeOut = timeOut;
	}


	public int getFeedback_id() {
		return feedback_id;
	}


	public void setFeedback_id(int feedback_id) {
		this.feedback_id = feedback_id;
	}


	public int getRollnumber() {
		return rollnumber;
	}


	public void setRollnumber(int rollnumber) {
		this.rollnumber = rollnumber;
	}


	public int getRequest_id() {
		return request_id;
	}


	public void setRequest_id(int request_id) {
		this.request_id = request_id;
	}


	public int getRating() {
		return rating;
	}


	public void setRating(int rating) {
		this.rating = rating;
	}


	public Time getTimeIn() {
		return timeIn;
	}


	public void setTimeIn(Time timeIn) {
		this.timeIn = timeIn;
	}


	public Time getTimeOut() {
		return timeOut;
	}


	public void setTimeOut(Time timeOut) {
		this.timeOut = timeOut;
	}


	@Override
	public String toString() {
		return "Feedback [feedback_id=" + feedback_id + ", rollnumber=" + rollnumber + ", request_id=" + request_id
				+ ", rating=" + rating + ", timeIn=" + timeIn + ", timeOut=" + timeOut + "]";
	}
	
	
	
	
	

}

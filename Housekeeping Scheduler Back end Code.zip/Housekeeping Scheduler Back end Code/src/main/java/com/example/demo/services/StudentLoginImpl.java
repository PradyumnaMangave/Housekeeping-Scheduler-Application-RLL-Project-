package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.StudentLogin;
import com.example.demo.repositories.StudentLoginRepository;

@Service
public class StudentLoginImpl implements StudentLoginService{
	
	
	@Autowired
	private StudentLoginRepository studentLoginRepository;
	
	public StudentLoginImpl(StudentLoginRepository studentLoginRepository) {
		super();
		this.studentLoginRepository = studentLoginRepository;
	}

	@Override
	public StudentLogin saveStudent(StudentLogin studentLogin)
	{
		return studentLoginRepository.save(studentLogin);
	}
	

}

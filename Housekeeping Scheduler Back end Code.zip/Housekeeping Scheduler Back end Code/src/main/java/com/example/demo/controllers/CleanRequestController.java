package com.example.demo.controllers;

import java.sql.Time;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.AdminLogin;
import com.example.demo.entities.CleanRequest;
import com.example.demo.services.CleanRequestService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/api")
public class CleanRequestController {
	
	@Autowired
	private CleanRequestService cleanRequestService;
	
	@GetMapping("/cleanRequests")
	public List<CleanRequest> getAllRequests()
	{
		return cleanRequestService.getAll();
	}
	
	@PostMapping("/cleanrequests")
	public ResponseEntity<CleanRequest> saveAdmin(@RequestBody CleanRequest request) {
		
		java.sql.Time time = new java.sql.Time(Calendar.getInstance().getTime().getTime());
		request.setTime(time);
		java.util.Date date = new java.util.Date();
		request.setDate(date);
		return new ResponseEntity<CleanRequest>(cleanRequestService.saveRequest(request), HttpStatus.CREATED);
}

}

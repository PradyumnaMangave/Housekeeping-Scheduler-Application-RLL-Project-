package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Update_Profile")
public class UpdateProfile {

		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		@Column(name = "rollnumber")
		private long rollnumber;
		@Column(name = "name")
		private String name;
		@Column(name = "password")
		private String password;
		@Column(name = "floor")
		private int floor;
		@Column(name = "roomNo")
		private int roomNo;
		
		
		public UpdateProfile() {
			super();
			// TODO Auto-generated constructor stub
		}


		public UpdateProfile(long rollnumber, String name, String password, int floor, int roomNo) {
			super();
			this.rollnumber = rollnumber;
			this.name = name;
			this.password = password;
			this.floor = floor;
			this.roomNo = roomNo;
		}


		public long getRollnumber() {
			return rollnumber;
		}


		public void setRollnumber(long rollnumber) {
			this.rollnumber = rollnumber;
		}


		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public String getPassword() {
			return password;
		}


		public void setPassword(String password) {
			this.password = password;
		}


		public int getFloor() {
			return floor;
		}


		public void setFloor(int floor) {
			this.floor = floor;
		}


		public int getRoomNo() {
			return roomNo;
		}


		public void setRoomNo(int roomNo) {
			this.roomNo = roomNo;
		}


		@Override
		public String toString() {
			return "UpdateProfile [rollnumber=" + rollnumber + ", name=" + name + ", password=" + password + ", floor="
					+ floor + ", roomNo=" + roomNo + "]";
		}
		
		

}

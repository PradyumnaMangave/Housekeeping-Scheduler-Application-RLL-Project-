package com.example.demo.entities;

import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Clean_Request")
public class CleanRequest {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "request_id")
	private long request_id;
	@Column(name = "rollnumber")
	private int rollnumber;
	@Column(name = "worker_id")
	private int worker_id;
	@Column(name = "time")
	private Time time;
	@Column(name = "date")
	private Date date;
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public CleanRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CleanRequest(long request_id, int rollnumber, int worker_id, Date date, Time time) {
		super();
		this.request_id = request_id;
		this.rollnumber = rollnumber;
		this.worker_id = worker_id;
		this.date = date;
		this.time=time;
		}
	
	public long getRequest_id() {
		return request_id;
	}
	public void setRequest_id(long request_id) {
		this.request_id = request_id;
	}
	public int getRollnumber() {
		return rollnumber;
	}
	public void setRollnumber(int rollnumber) {
		this.rollnumber = rollnumber;
	}
	public int getWorker_id() {
		return worker_id;
	}
	public void setWorker_id(int worker_id) {
		this.worker_id = worker_id;
	}
	public Time getTime() {
		return time;
	}
	public void setTime(Time time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "CleanRequest [request_id=" + request_id + ", rollnumber=" + rollnumber + ", worker_id=" + worker_id
				+ ", time=" + time + ", date=" + date + "]";
	}
	
}
	

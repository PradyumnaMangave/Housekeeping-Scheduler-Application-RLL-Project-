import { Component, OnInit } from '@angular/core';
import { CommonService } from "../services/common.service";
import { HttpService } from "../services/http.service";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent implements OnInit {

  hdata = [
    {"hname":"Lima","room": "Room-101","date": "2022-06-11","timere": "09:30 AM","tin":"12:30 PM","tout":"1:30 PM"},
    {"hname":"Noah","room": "Room-201","date": "2022-06-11","timere": "09:00 AM","tin":"12:30 PM","tout":"1:30 PM"},
    {"hname":"Oliver","room": "Room-301","date": "2022-06-09","timere": "11:30 PM","tin":"12:30 PM","tout":"1:30 PM"},
    {"hname":"James","room": "Room-401","date": "2022-06-09","timere": "10:50 AM","tin":"12:30 PM","tout":"1:30 PM"}

  ] 
  complaints: any =[];

  constructor(public https: HttpService, public common: CommonService) {
    if (sessionStorage.getItem('flag') == "false") {
      window.location.reload(true);
      sessionStorage.setItem('flag', 'true');
    }
  }
  

  ngOnInit(): void {
    this.getcomplaints();
  }

  getcomplaints(){
    try{
      this.https.commonGet("/api/cleanRequests").subscribe((res) => {
        console.log("res =====================", res  );
        this.complaints = JSON.parse(res);

        
        console.log("comp====================",this.complaints);
      
      })

    }catch(err){
      console.log("err====",err);
    }
  }


  }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../services/common.service';
import { HttpService } from '../services/http.service';

@Component({
  selector: 'app-suggestions',
  templateUrl: './suggestions.component.html',
  styleUrls: ['./suggestions.component.css']
})
export class SuggestionsComponent implements OnInit {

  
  hdata = [
    {"hname":"Lima","room": "Room-101","date": "2022-06-11","timere": "09:30 AM","tin":"12:30 PM","tout":"1:30 PM"},
    {"hname":"Noah","room": "Room-201","date": "2022-06-11","timere": "09:00 AM","tin":"12:30 PM","tout":"1:30 PM"},
    {"hname":"Oliver","room": "Room-301","date": "2022-06-09","timere": "11:30 PM","tin":"12:30 PM","tout":"1:30 PM"},

  ]
  

  complaints: any =[];


  constructor(public https: HttpService,
    public router: Router,
    public common: CommonService) { }

  ngOnInit(): void {
    this.getcomplaints();
  }

  getcomplaints(){
    try{
      this.https.commonGet("/api/cleanRequests").subscribe((res) => {
        console.log("res =====================", res  );
        this.complaints = JSON.parse(res);

        
        console.log("comp====================",this.complaints);
      
      })

    }catch(err){
      console.log("err====",err);
    }
  }

}

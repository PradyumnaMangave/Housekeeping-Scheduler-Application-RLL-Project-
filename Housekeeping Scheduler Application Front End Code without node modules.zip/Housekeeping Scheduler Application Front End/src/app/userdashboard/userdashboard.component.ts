import { Component, OnInit } from '@angular/core';
import { CommonService } from "../services/common.service";
import { HttpService } from "../services/http.service";

@Component({
  selector: 'app-userdashboard',
  templateUrl: './userdashboard.component.html',
  styleUrls: ['./userdashboard.component.css']
})
export class UserdashboardComponent implements OnInit {
  hdata = [
    {"hname":"Lima","room": "Room-101","date": "2022-06-11","timere": "09:30 AM","tin":"12:30 PM","tout":"1:30 PM"},
    {"hname":"Noah","room": "Room-201","date": "2022-06-11","timere": "09:00 AM","tin":"12:30 PM","tout":"1:30 PM"},
    {"hname":"Oliver","room": "Room-301","date": "2022-06-09","timere": "11:30 PM","tin":"12:30 PM","tout":"1:30 PM"},
    {"hname":"James","room": "Room-401","date": "2022-06-09","timere": "10:50 AM","tin":"12:30 PM","tout":"1:30 PM"}

  ]
  complaints: any = [];
  count: number = 0;

  constructor(public https: HttpService, public common: CommonService) {
    console.log("usertype ===", sessionStorage.getItem('flag'))
    if (sessionStorage.getItem('flag') == "true") {
      window.location.reload(true);
      sessionStorage.setItem('flag', 'false');
    }
  }

  ngOnInit(): void {
    this.getcomplaints();
  }

  getcomplaints() {
    try {
      this.https.commonGet("/api/cleanRequests").subscribe((res) => {
        console.log("res =====================", res);
        this.complaints = JSON.parse(res);
        this.count = this.complaints?this.complaints.length:0;

        console.log("comp====================", this.complaints);

      })

    } catch (err) {
      console.log("err====", err);
    }
  }


}
